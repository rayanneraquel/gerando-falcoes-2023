//Meu primeiro programa

import java.util.Scanner;
public class Soma {
    public static void main (String[]args) {
        Scanner entrada = new Scanner(System.in);
        int num1;
        int num2;
        System.out.print("Digite o primeiro numero: ");
        num1=entrada.nextInt();
        System.out.print("Digite o segundo numero: ");
        num2=entrada.nextInt();
        System.out.println();
        System.out.println(num1+" + "+num2+" = "+(num1+num2));
        System.out.println();
        System.out.println(num1+" - "+num2+" = "+(num1-num2));
        System.out.println();
        System.out.println(num1+" X "+num2+" = "+(num1*num2));
    }
    
}
