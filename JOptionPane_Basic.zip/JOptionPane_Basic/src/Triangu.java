import javax.swing.JOptionPane;

public class Triangu {
    public static void main(String[] args){
        double base, altura, area;
        
        base=Double.parseDouble(JOptionPane.showInputDialog("Digite a base do triangulo: "));
        altura=Double.parseDouble(JOptionPane.showInputDialog("Digite a altura do triangulo: "));
        
        area=(base*altura)/2;
        JOptionPane.showMessageDialog(null,"A area do triangulo é: "+area);
    }
}
