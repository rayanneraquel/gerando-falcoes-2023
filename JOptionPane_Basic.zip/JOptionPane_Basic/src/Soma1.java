import javax.swing.JOptionPane;
public class Soma1 {
    public static void main(String[] args){
     
        //declaração de variáveis
        double num1, num2, resultado;
        
        //captura de números
        num1=Double.parseDouble(JOptionPane.showInputDialog("Digite o primeiro valor: "));
        num2=Double.parseDouble(JOptionPane.showInputDialog("Digite o segundo valor: "));
        
        //processamento
        resultado=num1+num2;
        
        //saída de dados
        JOptionPane.showMessageDialog(null, "soma = "+resultado);
    }            
}
