import javax.swing.JoptionPane;

public class quadr {
    public static void main(String[] args){
        
        double lado1, lado2, area;
        
        lado1=Double.parseDouble(JOptionPane.showInputDialog("Digite o tamanho do primeiro lado: "));
    }
}
